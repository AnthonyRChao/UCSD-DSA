import java.util.*

fun main(args: Array<String>) {
    val s = Scanner(System.`in`)
    val a = s.nextInt()
    val b = s.nextInt()
    println(a + b)
}