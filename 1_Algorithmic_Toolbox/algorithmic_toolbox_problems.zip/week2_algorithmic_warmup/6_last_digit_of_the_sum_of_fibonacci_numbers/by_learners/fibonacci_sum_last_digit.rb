#!/usr/bin/env ruby
# by Andronik Ordian

def fib_sum_last_digit(n)
  # write your code here
  0
end

if __FILE__ == $0
  n = gets.to_i
  puts "#{fib_sum_last_digit(n)}"
end
